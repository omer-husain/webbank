function logOut() {
    alert("I am Logout");

}

